CREATE user malmos_hazifeladat_2 without login
grant SELECT ON Szallashely to malmos_hazifeladat_2
execute As user = 'malmos_hazifeladat_2'
SELECT * FROM Szallashely
revert
SELECT * FROM Szallashely