insert [Szallashely] ([SZALLAS_ID],[SZALLAS_NEV],[HELY],[CSILLAGOK_SZAMA],[TIPUS],[ROGZITETTE],[ROGZ_IDO],[CIM])
select 1,N'Sába-Ház',N'Balaton-dél',0,N'vendégház',N'Béla','2016-02-28',N'8630 Balatonboglár, Radnóti Miklós utca 8' UNION ALL
select 2,N'Családi Ház',N'Balaton-dél',0,N'vendégház',N'Béla','2016-03-02',N'8630 Balatonboglár, József Attila utca 25' UNION ALL
select 3,N'Fortuna Apartman',N'Hajdúbihar megye',0,N'Apartman',N'Sára','2016-03-06',N'4200 Hajdúszoboszló, Wesselényi utca 56.' UNION ALL
select 4,N'Fortuna panzió',N'Budapest',3,N'panzió',N'Béla','2016-03-07',N'1019 Budapest XIV. Cinkotai út 86.' UNION ALL
select 5,N'Fortuna Panzió',N'Békés megye',3,N'panzió',N'Sára','2016-03-08',N'5900 Orosháza, Gyopárosfürdő Tópart utca 3.' UNION ALL
select 6,N'Kentaur Hotel',N'Balaton-dél',3,N'Hotel',N'Béla','2016-03-08',N'8600 Siófok (Széplak), Akácfa utca 1' UNION ALL
select 7,N'Szieszta Apartmanház',N'Balaton-dél',0,N'Apartman',N'Mari','2016-03-11',N'8630 Balatonboglár, Dózsa György utca 108' UNION ALL
select 8,N'Hotel Három Hattyú',N'Balaton-dél',4,N'Hotel',N'Béla','2016-03-13',N'8623 Balatonföldvár, Rákóczi Ferenc út 45.' UNION ALL
select 9,N'Jáde panzió',N'Balaton-dél',3,N'panzió',N'Mari','2016-03-16',N'8624 Balatonföldvár, Kiss u.2.' UNION ALL
select 10,N'Lagúna Hotel',N'Budapest',4,N'Hotel',N'Sára','2016-03-20',N'1097 Budapest, Albert Flórián út 3' UNION ALL
select 11,N'Partiszél Vendégház',N'Balaton-észak',0,N'vendégház',N'Béla','2016-03-22',N'8220 Balatonalmádi Neptun u. 23.' UNION ALL
select 12,N'Gold Hotel',N'Budapest',3,N'Hotel',N'Béla','2016-03-24',N'1016 Budapest, Hegyalja út 12' UNION ALL
select 13,N'Riviéra Panzió',N'Csongrád megye',3,N'panzió',N'Sára','2016-03-27',N'6722 Szeged, Petőfi Sándor út 3.' UNION ALL
select 14,N'Nyárfás Vendégház',N'Csongrád megye',0,N'vendégház',N'Béla','2016-03-27',N'6723 Szeged, Nagy u. 12.' UNION ALL
select 15,N'Tímárház Panzió',N'Balaton-dél',3,N'panzió',N'Béla','2016-03-29',N'8600 Siófok, Virág utca 1' UNION ALL
select 16,N'Bagoly Hotel',N'Pest megye',3,N'Hotel',N'Mari','2016-04-01',N'2230 Gyömrő, Bergszász u. 5.' UNION ALL
select 17,N'Szarvas Hotel',N'Tolna megye',4,N'Hotel',N'Béla','2016-04-04',N'7121 Szálka, Petőfi Sándor u.' UNION ALL
select 18,N'Fortuna Apartman',N'Dél-Somogy',0,N'Apartman',N'Béla','2016-04-07',N'7570 Barcs, Kossuth u. 13.' UNION ALL
select 19,N'Nyárfás Vendégház',N'Dél-Somogy',0,N'vendégház',N'Sára','2016-04-07',N'7570 Barcs, Bajcsy-Zs. u. 53' UNION ALL
select 20,N'Kollégium',N'Budapest',0,N'Diákszálló',N'Sára','2016-04-07',N'1146 Budapest, Ajtósi Dürer sor 23.' UNION ALL
select 21,N'Müller Vendégház',N'Dél-Somogy',0,N'vendégház',N'Béla','2016-04-07',N'7570 Barcs, Magyar u. 10.';